// Add the script tag to the end of the HTML file
document.addEventListener('DOMContentLoaded', function() {
  // Get the HTML file
  fetch('/static/index.html')
    .then(response => response.text())
    .then(html => {
      // Check if the script is already added
      if (!html.includes('src="js/city-autocomplete.js"')) {
        // Find the closing body tag
        const bodyCloseIndex = html.lastIndexOf('</body>');
        
        // Insert our script tag before the closing body tag
        const updatedHtml = html.slice(0, bodyCloseIndex) + 
          '\n<script src="js/city-autocomplete.js"></script>\n' + 
          html.slice(bodyCloseIndex);
        
        // Save the updated HTML
        fetch('/update-html', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ html: updatedHtml }),
        });
      }
    });
});
