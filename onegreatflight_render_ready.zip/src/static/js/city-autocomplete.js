// Geoapify City Autocomplete Integration
document.addEventListener('DOMContentLoaded', function() {
  // Function to initialize city autocomplete
  function initCityAutocomplete(inputId, options = {}) {
    const input = document.getElementById(inputId);
    if (!input) return;
    
    // Create and append the autocomplete container
    const autocompleteContainer = document.createElement('div');
    autocompleteContainer.className = 'city-autocomplete-container';
    input.parentNode.insertBefore(autocompleteContainer, input.nextSibling);
    
    // Default options
    const defaultOptions = {
      type: 'city',
      limit: 5,
      placeholder: 'Enter city name...',
      debounceDelay: 300
    };
    
    // Merge options
    const settings = {...defaultOptions, ...options};
    
    // Set placeholder
    input.placeholder = settings.placeholder;
    
    // Debounce function to limit API calls
    let timeout = null;
    
    // Event listener for input changes
    input.addEventListener('input', function() {
      const query = this.value.trim();
      
      // Clear previous timeout
      clearTimeout(timeout);
      
      // Clear autocomplete container if query is empty
      if (!query) {
        autocompleteContainer.innerHTML = '';
        return;
      }
      
      // Set new timeout
      timeout = setTimeout(() => {
        fetchCitySuggestions(query, settings.type, settings.limit)
          .then(suggestions => {
            displaySuggestions(suggestions, autocompleteContainer, input);
          })
          .catch(error => {
            console.error('Error fetching city suggestions:', error);
          });
      }, settings.debounceDelay);
    });
    
    // Close autocomplete when clicking outside
    document.addEventListener('click', function(e) {
      if (!input.contains(e.target) && !autocompleteContainer.contains(e.target)) {
        autocompleteContainer.innerHTML = '';
      }
    });
  }
  
  // Function to fetch city suggestions from Geoapify API
  async function fetchCitySuggestions(query, type, limit) {
    // In a production environment, you would use your own API key
    // For demo purposes, we'll use a placeholder
    const apiKey = 'YOUR_GEOAPIFY_API_KEY';
    const url = `https://api.geoapify.com/v1/geocode/autocomplete?text=${encodeURIComponent(query)}&type=${type}&limit=${limit}&format=json&apiKey=${apiKey}`;
    
    // For demo purposes, return mock data
    // In production, uncomment the fetch code below
    /*
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('Failed to fetch city suggestions');
    }
    const data = await response.json();
    return data.results || [];
    */
    
    // Mock data for demonstration
    return [
      {
        formatted: 'Sydney, New South Wales, Australia',
        city: 'Sydney',
        country: 'Australia',
        state: 'New South Wales',
        lat: -33.8688,
        lon: 151.2093
      },
      {
        formatted: 'Singapore, Singapore',
        city: 'Singapore',
        country: 'Singapore',
        state: '',
        lat: 1.3521,
        lon: 103.8198
      },
      {
        formatted: 'London, England, United Kingdom',
        city: 'London',
        country: 'United Kingdom',
        state: 'England',
        lat: 51.5074,
        lon: -0.1278
      },
      {
        formatted: 'Paris, Île-de-France, France',
        city: 'Paris',
        country: 'France',
        state: 'Île-de-France',
        lat: 48.8566,
        lon: 2.3522
      },
      {
        formatted: 'New York, New York, United States',
        city: 'New York',
        country: 'United States',
        state: 'New York',
        lat: 40.7128,
        lon: -74.0060
      }
    ];
  }
  
  // Function to display suggestions in the autocomplete container
  function displaySuggestions(suggestions, container, input) {
    // Clear previous suggestions
    container.innerHTML = '';
    
    if (!suggestions.length) {
      const noResults = document.createElement('div');
      noResults.className = 'autocomplete-item no-results';
      noResults.textContent = 'No cities found';
      container.appendChild(noResults);
      return;
    }
    
    // Create suggestion items
    suggestions.forEach(suggestion => {
      const item = document.createElement('div');
      item.className = 'autocomplete-item';
      
      // Create main text (city name)
      const mainText = document.createElement('div');
      mainText.className = 'autocomplete-main-text';
      mainText.textContent = suggestion.city;
      
      // Create secondary text (country and state)
      const secondaryText = document.createElement('div');
      secondaryText.className = 'autocomplete-secondary-text';
      secondaryText.textContent = suggestion.state ? 
        `${suggestion.state}, ${suggestion.country}` : 
        suggestion.country;
      
      // Append text elements to item
      item.appendChild(mainText);
      item.appendChild(secondaryText);
      
      // Add click event to select this suggestion
      item.addEventListener('click', function() {
        input.value = suggestion.formatted;
        container.innerHTML = '';
        
        // Store coordinates as data attributes for potential use
        input.dataset.lat = suggestion.lat;
        input.dataset.lon = suggestion.lon;
        
        // Trigger change event
        const event = new Event('change', { bubbles: true });
        input.dispatchEvent(event);
      });
      
      container.appendChild(item);
    });
  }
  
  // Initialize autocomplete for departure and destination city inputs
  initCityAutocomplete('departure_city', {
    placeholder: 'Enter departure city...'
  });
  
  initCityAutocomplete('destination_city', {
    placeholder: 'Enter destination city...'
  });
});
